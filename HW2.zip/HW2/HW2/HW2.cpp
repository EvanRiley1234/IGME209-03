#include <iostream>
#include <Box2D.h>
#include <conio.h>
#include <stdlib.h>
#include <iostream>
#include <ctime>
#include "Snake.h"
#include "Box2D/Common/b2Settings.h"
#include "Box2D/Common/b2Draw.h"
#include "Box2D/Common/b2Timer.h"

#include "Box2D/Collision/Shapes/b2CircleShape.h"
#include "Box2D/Collision/Shapes/b2EdgeShape.h"
#include "Box2D/Collision/Shapes/b2ChainShape.h"
#include "Box2D/Collision/Shapes/b2PolygonShape.h"

#include "Box2D/Collision/b2BroadPhase.h"
#include "Box2D/Collision/b2Distance.h"
#include "Box2D/Collision/b2DynamicTree.h"
#include "Box2D/Collision/b2TimeOfImpact.h"

#include "Box2D/Dynamics/b2Body.h"
#include "Box2D/Dynamics/b2Fixture.h"
#include "Box2D/Dynamics/b2WorldCallbacks.h"
#include "Box2D/Dynamics/b2TimeStep.h"
#include "Box2D/Dynamics/b2World.h"

#include "Box2D/Dynamics/Contacts/b2Contact.h"

#include "Box2D/Dynamics/Joints/b2DistanceJoint.h"
#include "Box2D/Dynamics/Joints/b2FrictionJoint.h"
#include "Box2D/Dynamics/Joints/b2GearJoint.h"
#include "Box2D/Dynamics/Joints/b2MotorJoint.h"
#include "Box2D/Dynamics/Joints/b2MouseJoint.h"
#include "Box2D/Dynamics/Joints/b2PrismaticJoint.h"
#include "Box2D/Dynamics/Joints/b2PulleyJoint.h"
#include "Box2D/Dynamics/Joints/b2RevoluteJoint.h"
#include "Box2D/Dynamics/Joints/b2RopeJoint.h"
#include "Box2D/Dynamics/Joints/b2WeldJoint.h"
#include "Box2D/Dynamics/Joints/b2WheelJoint.h"

int main()
{
	//variables for while loop
	bool escapePress = false;


	//creating the physics world
	b2Vec2 gravity(0.0f, -0.1f);
	b2World world(gravity);

	//number of keypresses and score
	int keyPresses = 0;
	int targetsHit = 0;

	b2Vec2 snakePositionM;

	//position for the target
	float targetX = 0;
	float targetY = 0;

	//create the snake body as a dynamic body
	b2BodyDef snakeBody;
	snakeBody.type = b2_dynamicBody;
	snakeBody.position.Set(0.0f, 4.0f);
	b2Body* sBody = world.CreateBody(&snakeBody);
	//attach a polygon shape to it
	b2PolygonShape dynamicBox;
	dynamicBox.SetAsBox(1.0f, 1.0f);
	b2FixtureDef fixtureDef;
	fixtureDef.shape = &dynamicBox;
	fixtureDef.density = 1.0f;
	fixtureDef.friction = 0.3f;
	sBody->CreateFixture(&fixtureDef);

	
	moveTarget(targetX, targetY);
	//while loop for running

	std::cout << "Welcome to Gravity Snake\n";
	std::cout << "Use W, A, and S to move\n";


	while (targetsHit < 4 && !escapePress)
	{
		update(world, sBody, targetX, targetY, snakePositionM);
		display(sBody, targetX, targetY);
		if (_kbhit())
		{
			applyForces(sBody);
			keyPresses++;
		}
		if (targetX == snakePositionM.x && snakePositionM.y == targetY)
		{
			moveTarget(targetX, targetY);
			targetsHit++;
		}
		if (_kbhit() && _getch() == 27)
		{
			escapePress = true;
		}

		
	}

	std::cout << "Your number of key presses: " << targetsHit;
}
